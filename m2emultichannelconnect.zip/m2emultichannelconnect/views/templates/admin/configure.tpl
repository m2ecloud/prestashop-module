{**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2026 M2E LTD
 * @license    Any usage is forbidden
 *}

{if count($issues) > 0}
    <div class="alert alert-danger">
        <p>
            <b>Action Required</b><br><br>
            {foreach $issues as $issue}
                We’re unable to reach your PrestaShop store right now. It may be caused by: <b>{$issue.message|escape:'html':'UTF-8'}</b>.
                {if $issue.link }
                    Please follow the
                    <a href="{$issue.link|escape:'html':'UTF-8'}" target="_blank" style="text-decoration: underline;">
                        <strong>step-by-step </strong>
                    </a>
                    guide to resolve this issue.
                {/if}
            {/foreach}
        </p>
        <br>
        <a href="{$smarty.server.REQUEST_URI|escape:'html':'UTF-8'}" class="btn btn-default">
            <i class="material-icons">refresh</i> Recheck connection
        </a>
    </div>
{else}
    <div class="alert alert-success">
        <p>
            Congratulations on completing the installation.<br>
            Please navigate to <strong>[Sell]</strong> →

            {if !empty($link)}
                <a href="{$link|escape:'html':'UTF-8'}" style="text-decoration: underline;">
                    <strong>{$name|escape:'html':'UTF-8'}</strong>
                </a>
            {else}
                <strong>{$name|escape:'html':'UTF-8'}</strong>
            {/if}
            to proceed with further steps.
        </p>
    </div>
{/if}
