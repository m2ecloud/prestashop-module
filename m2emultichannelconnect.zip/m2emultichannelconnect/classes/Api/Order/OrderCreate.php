<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/OrderBuilder.php';

use PrestaShop\PrestaShop\Adapter\ServiceLocator;

class OrderCreate
{
    public function process(array $input)
    {
        $orderData = $input['order'];

        $currency = Currency::getCurrencyInstance(Currency::getIdByIsoCode($orderData['currency']));
        $shop = new Shop((int) Configuration::get('PS_SHOP_DEFAULT'));
        $lang = new Language((int) Configuration::get('PS_LANG_DEFAULT'));
        $cart = new Cart();

        $customerData = $orderData['customer'];
        if ($customerId = Customer::customerExists($customerData['email'], true)) {
            $customer = new Customer($customerId);
        } else {
            $customer = new Customer();
            $customer->email = $customerData['email'];
            $customer->firstname = $customerData['first_name'];
            $customer->lastname = $customerData['last_name'];

            /** @var \PrestaShop\PrestaShop\Core\Crypto\Hashing $crypto */
            $crypto = ServiceLocator::get('\\PrestaShop\\PrestaShop\\Core\\Crypto\\Hashing');
            $customer->passwd = $crypto->hash(Tools::passwdGen());

            $customer->add();
        }

        $addressData = $orderData['address'];
        $address = new Address();
        $address->id_customer = $customer->id;
        $address->firstname = $addressData['first_name'];
        $address->lastname = $addressData['last_name'];
        $address->id_country = Country::getByIso($addressData['country_code']);
        if (!empty($addressData['state']) && ($idState = State::getIdByName((string) $addressData['state']))) {
            $address->id_state = $idState;
        } elseif (!empty($addressData['state_code']) && ($idState = State::getIdByIso($addressData['state_code'], $address->id_country))) {
            $address->id_state = $idState;
        }
        if (!empty($addressData['postal_code'])) {
            $address->postcode = $addressData['postal_code'];
        }
        $address->address1 = $addressData['address1'];
        $address->address2 = (string) $addressData['address2'];
        $address->city = $addressData['city'];
        if (!empty($addressData['phone'])) {
            $address->phone = $addressData['phone'];
        }
        $address->alias = $addressData['alias'];
        $address->dni = '0000';
        $address->add();

        $cart->id_customer = $customer->id;
        $cart->id_address_delivery = $address->id;
        $cart->id_address_invoice = $address->id;
        $cart->id_currency = $currency->id;
        $cart->id_lang = $lang->id;

        $idCarrier = Carrier::getDefaultCarrierSelection(
            Carrier::getCarriers($lang->id, true, false, false, null, Carrier::ALL_CARRIERS)
        );
        if (!$idCarrier) {
            throw new Exception('Default carrier not set');
        }

        $cart->id_carrier = $idCarrier;
        $cart->add();

        foreach ($orderData['line_items'] as $lineItemData) {
            $cart->updateQty((int) $lineItemData['product_quantity'], (int) $lineItemData['product_id'], (int) $lineItemData['product_attribute_id']);
        }

        $order = new Order();
        $order->id_cart = $cart->id;
        $order->id_customer = $customer->id;
        $order->id_address_delivery = $address->id;
        $order->id_address_invoice = $address->id;
        $order->id_currency = $currency->id;
        $order->id_lang = $lang->id;
        $order->id_carrier = $cart->id_carrier;
        $order->module = 'm2emultichannelconnect';
        $order->payment = 'Remote Payment';
        $order->total_paid = $orderData['total_paid'];
        $order->total_paid_real = $orderData['total_paid'];
        $order->total_paid_tax_excl = $orderData['total_paid_tax_excl'];
        $order->total_paid_tax_incl = $orderData['total_paid_tax_incl'];
        $order->total_products = 0;
        $order->total_products_wt = 0;
        $order->total_shipping = $orderData['shipping_cost_tax_incl'];
        $order->total_shipping_tax_excl = $orderData['shipping_cost_tax_excl'];
        $order->conversion_rate = 1;
        $order->secure_key = $customer->secure_key;
        $order->id_shop = $shop->id;
        $order->id_shop_group = $shop->id_shop_group;
        $order->reference = !empty($orderData['reference']) ? $orderData['reference'] : Order::generateReference();

        $order->add();

        foreach ($orderData['line_items'] as $lineItemData) {
            $product = new Product($lineItemData['product_id']);
            $productAttributeId = $lineItemData['product_attribute_id'] ? (int) $lineItemData['product_attribute_id'] : null;
            if ($productAttributeId) {
                $combination = new Combination($productAttributeId);
                $productReference = $combination->reference;
            } else {
                $productReference = $product->reference;
            }

            $detail = new OrderDetail();
            $detail->id_order = $order->id;
            $detail->product_id = $product->id;
            $detail->product_attribute_id = $productAttributeId;
            $detail->product_name = Product::getProductName($product->id, $productAttributeId);
            $detail->product_quantity = $lineItemData['product_quantity'];
            $detail->original_product_price = $lineItemData['original_product_price'];
            $detail->product_price = $lineItemData['original_product_price'];
            $detail->total_price_tax_incl = $lineItemData['total_price_tax_incl'];
            $detail->total_price_tax_excl = $lineItemData['total_price_tax_excl'];
            $detail->unit_price_tax_excl = $lineItemData['unit_price_tax_excl'];
            $detail->unit_price_tax_incl = $lineItemData['unit_price_tax_incl'];
            $detail->id_warehouse = 0;
            $detail->id_shop = $shop->id;
            $detail->product_reference = $productReference;
            $detail->add();

            $order->total_products += $detail->total_price_tax_excl;
            $order->total_products_wt += $detail->total_price_tax_incl;
            $order->total_paid += $detail->total_price_tax_incl;
        }

        $order->update();

        $status = $this->resolvePSStatus($orderData['status']);
        if (!$status) {
            throw new Exception('Unable to resolve order status');
        }
        $order->setCurrentState($status);

        foreach ($order->getOrderDetailList() as $detail) {
            $id_product = (int) $detail['product_id'];
            $id_product_attribute = (int) $detail['product_attribute_id'];
            $quantity = (int) $detail['product_quantity'];

            StockAvailable::updateQuantity(
                $id_product,
                $id_product_attribute,
                -$quantity
            );
        }

        $orderCarrier = new OrderCarrier();
        $orderCarrier->id_order = $order->id;
        $orderCarrier->id_carrier = $order->id_carrier;
        $orderCarrier->weight = $order->getTotalWeight();
        $orderCarrier->shipping_cost_tax_excl = $order->total_shipping_tax_excl;
        $orderCarrier->shipping_cost_tax_incl = $order->total_shipping_tax_incl;
        if (!empty($orderData['tracking_number'])) {
            $orderCarrier->tracking_number = $orderData['tracking_number'];
        }

        $orderCarrier->add();

        return ['order' => OrderBuilder::buildOrder($order)];
    }

    private function resolvePSStatus($status)
    {
        switch ($status) {
            case 'unshipped':
                return Configuration::get('PS_OS_PAYMENT');
            case 'shipped':
                return Configuration::get('PS_OS_SHIPPING');
            case 'cancelled':
                return Configuration::get('PS_OS_CANCELED');
            default:
                return Configuration::get('PS_OS_BANKWIRE');
        }
    }
}
