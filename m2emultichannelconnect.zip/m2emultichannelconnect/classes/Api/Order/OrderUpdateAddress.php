<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/OrderBuilder.php';

class OrderUpdateAddress
{
    public function process(array $input)
    {
        $addressData = $input['address'];

        $addressId = $addressData['id'];
        $firstName = $addressData['first_name'];
        $lastName = $addressData['last_name'];
        $countryCode = $addressData['country_code'];
        $stateCode = $addressData['state_code'];
        $postalCode = $addressData['postal_code'];
        $address1 = $addressData['address1'];
        $city = $addressData['city'];
        $phone = $addressData['phone'];
        $alias = $addressData['alias'];

        $address = new Address($addressId);
        if (!Validate::isLoadedObject($address)) {
            throw new Exception('Address not found.', 400);
        }

        $address->firstname = $firstName;
        $address->lastname = $lastName;
        $address->id_country = Country::getByIso($countryCode);
        if (!empty($stateCode)) {
            if ($idState = State::getIdByIso($stateCode, $address->id_country)) {
                $address->id_state = $idState;
            }
        }
        if (!empty($postalCode)) {
            $address->postcode = $postalCode;
        }
        $address->address1 = $address1;
        $address->city = $city;
        if (!empty($phone)) {
            $address->phone = $phone;
        }
        $address->alias = $alias;
        $address->update();

        return ['address' => OrderBuilder::buildAddressFromId($addressId)];
    }
}
