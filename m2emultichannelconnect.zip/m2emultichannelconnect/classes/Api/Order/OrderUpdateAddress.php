<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/OrderBuilder.php';

class OrderUpdateAddress
{
    public function process(array $input)
    {
        $addressData = $input['address'];

        $addressId = $addressData['id'];
        $firstName = $addressData['first_name'];
        $lastName = $addressData['last_name'];
        $countryCode = $addressData['country_code'];
        $address1 = $addressData['address1'];
        $city = $addressData['city'];
        $alias = $addressData['alias'];

        $address = new Address($addressId);
        if (!Validate::isLoadedObject($address)) {
            throw new Exception('Address not found.', 400);
        }

        $address->firstname = $firstName;
        $address->lastname = $lastName;
        $address->id_country = Country::getByIso($countryCode);
        $address->address1 = $address1;
        $address->city = $city;
        $address->alias = $alias;
        $address->update();

        return ['address' => OrderBuilder::buildAddressFromId($addressId)];
    }
}
