<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/OrderBuilder.php';

class OrderUpdateAddress
{
    public function process(array $input)
    {
        $addressData = $input['address'];

        $addressId = $addressData['id'];
        $firstName = $addressData['first_name'];
        $lastName = $addressData['last_name'];
        $countryCode = $addressData['country_code'];
        $stateCode = $addressData['state_code'];
        $postalCode = $addressData['postal_code'];
        $address1 = $addressData['address1'];
        $address2 = (string) $addressData['address2'];
        $city = $addressData['city'];
        $phone = $addressData['phone'];
        $alias = $addressData['alias'];

        $address = new Address($addressId);
        if (!Validate::isLoadedObject($address)) {
            throw new Exception('Address not found.', 400);
        }

        $address->firstname = $firstName;
        $address->lastname = $lastName;

        $country = new Country(Country::getByIso($countryCode));
        if (!Validate::isLoadedObject($country)) {
            throw new Exception("Unknown country: $countryCode", 400);
        }
        $address->id_country = $country->id;
        if (!empty($stateCode)) {
            if ($idState = State::getIdByName($addressData['state'])) {
                $address->id_state = $idState;
            } elseif ($idState = State::getIdByIso($addressData['state_code'], $address->id_country)) {
                $address->id_state = $idState;
            }
        }
        if (!empty($postalCode)) {
            if ($country->checkZipCode($postalCode)) {
                $address->postcode = $postalCode;
            } elseif ($country->need_zip_code) {
                throw new Exception("Invalid postcode: $postalCode. Valid format: " . Country::getZipCodeFormat($country->id), 400);
            }
        }
        $address->address1 = $address1;
        $address->address2 = $address2;
        $address->city = $city;
        if (!empty($phone)) {
            $address->phone = $phone;
        }
        $address->alias = $alias;
        $address->update();

        return ['address' => OrderBuilder::buildAddressFromId($addressId)];
    }
}
