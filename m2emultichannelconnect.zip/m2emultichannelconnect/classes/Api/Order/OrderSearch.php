<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/OrderBuilder.php';

class OrderSearch
{
    public function process(array $input)
    {
        $updatedFrom = $input['updated_from'];
        $updatedTo = $input['updated_to'];
        $id = $input['id'];
        $page = $input['page'];
        $limit = $input['limit'];
        $offset = (int) (($page - 1) * $limit);

        $where = '1';
        if ($updatedFrom) {
            $where .= ' AND o.date_upd >= "' . pSQL($updatedFrom) . '"';
        }
        if ($updatedTo) {
            $where .= ' AND o.date_upd <= "' . pSQL($updatedTo) . '"';
        }
        if ($id) {
            $where .= ' AND o.id_order = ' . pSQL($id);
        }

        $countSql = '
            SELECT COUNT(*) FROM ' . _DB_PREFIX_ . 'orders o
            WHERE ' . $where;
        $total = (int) Db::getInstance()->getValue($countSql);

        $sql = '
            SELECT o.*
            FROM ' . _DB_PREFIX_ . 'orders o
            WHERE ' . $where . '
            ORDER BY o.date_upd
            LIMIT ' . $limit . ' OFFSET ' . $offset;

        $ordersRaw = Db::getInstance()->executeS($sql);
        $orders = [];
        foreach ($ordersRaw as $orderRow) {
            $orders[] = OrderBuilder::buildOrderFromId($orderRow['id_order']);
        }

        return [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'orders' => $orders,
        ];
    }
}
