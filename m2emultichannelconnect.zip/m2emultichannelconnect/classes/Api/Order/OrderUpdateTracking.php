<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/OrderBuilder.php';

class OrderUpdateTracking
{
    public function process(array $input)
    {
        $orderId = $input['order_id'];
        $trackingNumber = $input['tracking_number'];

        $order = new Order($orderId);
        if (!Validate::isLoadedObject($order)) {
            throw new Exception('Order not found.', 400);
        }

        $orderCarrier = new OrderCarrier($order->getIdOrderCarrier());
        $orderCarrier->tracking_number = $trackingNumber;
        $orderCarrier->update();

        return ['order' => OrderBuilder::buildOrder($order)];
    }
}
