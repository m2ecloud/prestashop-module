<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class OrderBuilder
{
    public static function buildOrderFromId($orderId)
    {
        $order = new Order($orderId);

        return self::buildOrder($order);
    }

    public static function buildOrder(Order $order)
    {
        $invoice = new Address($order->id_address_invoice);
        $carrier = new Carrier($order->id_carrier);
        $orderState = $order->getCurrentOrderState();

        $lineItems = array_map(function ($item) {
            return [
                'id' => $item['id_order_detail'],
                'product_id' => $item['product_id'],
                'product_attribute_id' => $item['product_attribute_id'],
                'product_name' => $item['product_name'],
                'product_reference' => $item['product_reference'],
                'product_ean13' => $item['product_ean13'],
                'product_upc' => $item['product_upc'],
                'product_quantity' => (int) $item['product_quantity'],
                'original_product_price' => (float) $item['original_product_price'],
                'unit_price_tax_incl' => (float) $item['unit_price_tax_incl'],
                'unit_price_tax_excl' => (float) $item['unit_price_tax_excl'],
                'total_price_tax_incl' => (float) $item['total_price_tax_incl'],
                'total_price_tax_excl' => (float) $item['total_price_tax_excl'],
                'reduction_percent' => (float) $item['reduction_percent'],
                'reduction_amount' => (float) $item['reduction_amount'],
            ];
        }, $order->getOrderDetailList());

        return [
            'id' => $order->id,
            'reference' => $order->reference,
            'currency' => Currency::getCurrencyInstance($order->id_currency)->iso_code,
            'secure_key' => $order->secure_key,
            'total_paid' => (float) $order->total_paid,
            'total_paid_tax_excl' => (float) $order->total_paid_tax_excl,
            'total_paid_tax_incl' => (float) $order->total_paid_tax_incl,
            'sub_total_tax_excl' => (float) $order->getTotalProductsWithoutTaxes(),
            'sub_total_tax_incl' => (float) $order->getTotalProductsWithTaxes(),
            'shipping_cost_tax_incl' => (float) $order->total_shipping_tax_incl,
            'shipping_cost_tax_excl' => (float) $order->total_shipping_tax_excl,
            'payment' => $order->payment,
            'module' => $order->module,
            'shipping_carrier_name' => $carrier->name,
            'shipping_number' => $order->getShippingNumber(),
            'delivery_date' => $order->delivery_date,
            'delivery_number' => $order->delivery_number,
            'invoice_number' => $order->invoice_number,
            'status' => self::resolveStatus($orderState),
            'create_date' => $order->date_add,
            'update_date' => $order->date_upd,
            'customer' => self::buildCustomerFromId($order->id_customer),
            'address' => self::buildAddressFromId($order->id_address_delivery),
            'invoice_address' => [
                'id' => $invoice->id,
                'alias' => $invoice->alias,
                'address1' => $invoice->address1,
                'address2' => $invoice->address2,
                'postcode' => $invoice->postcode,
                'city' => $invoice->city,
                'country_code' => Country::getIsoById($invoice->id_country),
                'phone' => $invoice->phone,
            ],
            'line_items' => $lineItems,
            'messages' => array_map(function ($message) {
                return [
                    'message' => $message['message'],
                    'date_add' => $message['date_add'],
                ];
            }, Message::getMessagesByOrderId($order->id)),
            'discounts' => array_map(function ($cartRule) {
                return [
                    'id_cart_rule' => $cartRule['id_cart_rule'],
                    'name' => $cartRule['name'],
                    'value' => $cartRule['value'],
                ];
            }, $order->getCartRules()),
            'transactions' => array_map(function ($payment) {
                return [
                    'payment_method' => $payment->payment_method,
                    'amount' => $payment->amount,
                    'transaction_id' => $payment->transaction_id,
                    'date_add' => $payment->date_add,
                ];
            }, $order->getOrderPaymentCollection()->getResults()),
        ];
    }

    public static function buildAddressFromId($addressId)
    {
        $address = new Address($addressId);

        return [
            'id' => $address->id,
            'first_name' => $address->firstname,
            'last_name' => $address->lastname,
            'alias' => $address->alias,
            'address1' => $address->address1,
            'address2' => $address->address2,
            'postcode' => $address->postcode,
            'city' => $address->city,
            'country_code' => Country::getIsoById($address->id_country),
            'phone' => $address->phone,
        ];
    }

    public static function buildCustomerFromId($customerId)
    {
        $customer = new Customer($customerId);
        if ($customer->id === null) {
            return null;
        }

        return [
            'id' => $customer->id,
            'email' => $customer->email,
            'first_name' => $customer->firstname,
            'last_name' => $customer->lastname,
        ];
    }

    public static function resolveStatus(OrderState $state)
    {
        if ($state->id === (int) Configuration::get('PS_OS_CANCELED')) {
            return 'cancelled';
        }

        if ($state->shipped) {
            return 'shipped';
        }

        if ($state->paid) {
            return 'unshipped';
        }

        return 'pending';
    }
}
