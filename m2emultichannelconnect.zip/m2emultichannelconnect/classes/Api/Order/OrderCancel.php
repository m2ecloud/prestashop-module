<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/OrderBuilder.php';

class OrderCancel
{
    public function process(array $input)
    {
        $orderId = $input['order_id'];

        $order = new Order($orderId);
        if (!Validate::isLoadedObject($order)) {
            throw new Exception('Order not found', 400);
        }

        $state = (int) Configuration::get('PS_OS_CANCELED');
        if (!$state) {
            throw new Exception('Canceled order state not configured', 500);
        }

        $history = new OrderHistory();
        $history->id_order = $order->id;
        $history->changeIdOrderState($state, $order->id);
        $history->addWithemail(false);

        return ['order' => OrderBuilder::buildOrder($order)];
    }
}
