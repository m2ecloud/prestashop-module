<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2026 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

if (!interface_exists('WebserviceSpecificManagementInterface')) {
    @require_once _PS_ROOT_DIR_ . '/classes/webservice/WebserviceSpecificManagementInterface.php';
}

require_once dirname(__FILE__) . '/Api/Order/OrderCancel.php';
require_once dirname(__FILE__) . '/Api/Order/OrderCreate.php';
require_once dirname(__FILE__) . '/Api/Order/OrderSearch.php';
require_once dirname(__FILE__) . '/Api/Order/OrderShip.php';
require_once dirname(__FILE__) . '/Api/Order/OrderUpdateAddress.php';
require_once dirname(__FILE__) . '/Api/Order/OrderUpdateTracking.php';

class WebserviceSpecificManagementM2E implements WebserviceSpecificManagementInterface
{
    /** @var WebserviceOutputBuilderCore */
    protected $objOutput;

    /** @var WebserviceRequestCore */
    protected $wsObject;

    /** @var array */
    protected $output;

    /** @var int */
    protected $statusCode = 200;

    public function setObjectOutput($obj)
    {
        $this->objOutput = $obj;
        return $this;
    }

    public function getObjectOutput()
    {
        return $this->objOutput;
    }

    public function setWsObject($obj)
    {
        $this->wsObject = $obj;
        return $this;
    }

    public function getWsObject()
    {
        return $this->wsObject;
    }

    public function manage()
    {
        try {
            $this->output = $this->manageM2e();
        } catch (NotFoundHttpException $e) {
            $this->output = $this->error(sprintf('Route "%s" does not exist.', implode('/', $this->wsObject->urlSegment)), 404);
        } catch (Exception $e) {
            $this->output = $this->error($e->getMessage(), 400);
        }

        return true;
    }

    public function manageM2e()
    {
        switch ($this->wsObject->urlSegment[1]) {
            case 'orders':
                return $this->manageOrders();
            default:
                throw new NotFoundHttpException();
        }
    }

    public function manageOrders()
    {
        $input = $this->getInput();

        switch ($this->wsObject->urlSegment[2]) {
            case 'cancel':
                return (new OrderCancel())->process($input);
            case 'create':
                return (new OrderCreate())->process($input);
            case 'search':
                return (new OrderSearch())->process($input);
            case 'ship':
                return (new OrderShip())->process($input);
            case 'update-address':
                return (new OrderUpdateAddress())->process($input);
            case 'update-tracking':
                return (new OrderUpdateTracking())->process($input);
            default:
                throw new NotFoundHttpException();
        }
    }

    public function getContent()
    {
        $this->objOutput->setHeaderParams('Content-Type', 'application/json');
        $this->objOutput->setStatus($this->statusCode);
        $content = json_encode($this->output, JSON_UNESCAPED_UNICODE);

        if (ob_get_level() > 0) {
            ob_clean();
        }

        return (false !== $content) ? $content : '';
    }

    private function getInput()
    {
        $rawInput = file_get_contents('php://input');
        $data = json_decode($rawInput, true);

        if (!is_array($data)) {
            throw new Exception('Invalid JSON');
        }

        return $data;
    }

    protected function error($message, $code)
    {
        $this->statusCode = $code;

        return ['message' => $message, 'code' => $code];
    }
}
