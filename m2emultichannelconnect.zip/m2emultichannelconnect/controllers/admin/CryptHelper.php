<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class CryptHelper
{
    public static function hmacSha256($data, $key)
    {
        return hash_hmac('sha256', $data, $key);
    }
}
