<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/CryptHelper.php';

class AdminM2EMultichannelConnectController extends ModuleAdminController
{
    const MODULE_NAME = 'm2emultichannelconnect';

    private $moduleVersion = '1.2.2';

    public function __construct()
    {
        $this->bootstrap = true;

        if ($module = Module::getInstanceByName(self::MODULE_NAME)) {
            $this->moduleVersion = $module->version;
        }

        parent::__construct();
    }

    public function initContent()
    {
        parent::initContent();

        $state = base64_encode((string) time());

        $url = sprintf(
            'https://m2e.cloud/?prestashop_embedded=true&version=%s&source=%s&domain=%s&state=%s&signature=%s',
            $this->moduleVersion,
            'github',
            urlencode(Tools::getShopDomain()),
            $state,
            CryptHelper::hmacSha256($state, M2eMultichannelConnect::getWebserviceKey(self::MODULE_NAME))
        );

        $this->context->smarty->assign([
            'content' => "
<div style='height: 75vh'>
<iframe src=\"$url\" style=\"display: block; width: 100%; height: 100%; border: none;\">
</iframe>
</div>
",
        ]);
    }
}
