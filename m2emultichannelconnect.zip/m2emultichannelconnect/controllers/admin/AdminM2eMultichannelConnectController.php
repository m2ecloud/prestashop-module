<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2026 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminM2EMultichannelConnectController extends ModuleAdminController
{
    /** @var M2eMultichannelConnect */
    public $module;

    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function initContent()
    {
        parent::initContent();

        $state = base64_encode((string) time());

        $url = sprintf(
            'https://m2e.cloud/?prestashop_embedded=true&version=%s&source=%s&domain=%s&state=%s&signature=%s',
            $this->module->version,
            'github',
            urlencode(Tools::getShopDomain()),
            $state,
            $this->module->buildSignature($state)
        );

        $this->context->smarty->assign([
            'content' => "
<div style='height: 75vh'>
<iframe src=\"$url\" style=\"display: block; width: 100%; height: 100%; border: none;\">
</iframe>
</div>
",
        ]);
    }
}
