<?php

class AdminM2eMultichannelConnectController extends ModuleAdminController
{
    const MODULE_NAME = 'm2emultichannelconnect';

    private $moduleVersion = '1.0.0';

    public function __construct()
    {
        $this->bootstrap = true;

        if ($module = Module::getInstanceByName(self::MODULE_NAME)) {
            $this->moduleVersion = $module->version;
        }

        parent::__construct();
    }

    public function initContent()
    {
        parent::initContent();

        $state = base64_encode(time());

        $url = sprintf(
            'https://m2e.cloud/?prestashop_embedded=true&version=%s&domain=%s&state=%s&signature=%s',
            $this->moduleVersion,
            urlencode(Tools::getShopDomain()),
            $state,
            hash_hmac('sha256', $state, M2eMultichannelConnect::getWebserviceKey(self::MODULE_NAME))
        );

        $this->context->smarty->assign([
            'content' => "<div style='height: 75vh'><iframe src=\"$url\" style=\"display: block; width: 100%; height: 100%; border: none;\"></iframe></div>"
        ]);
    }
}
