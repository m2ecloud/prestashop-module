<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Adapter\SymfonyContainer;

class M2eMultichannelConnect extends Module
{
    const ADMIN_TAB_CLASS_NAME = 'AdminM2EMultichannelConnect';

    public function __construct()
    {
        $this->name = 'm2emultichannelconnect';
        $this->version = '1.2.6';
        $this->author = 'M2E LTD';
        $this->bootstrap = true;
        $this->tab = 'administration';
        $this->ps_versions_compliancy = ['min' => '1.7.0.0', 'max' => _PS_VERSION_];

        parent::__construct();

        $this->displayName = 'M2E Multichannel Connect';
        $this->description = 'Powered by M2E, the M2E Multichannel Connect extension allows Prestashop store owners to integrate
            and synchronize their product catalogs with Amazon, eBay, and Walmart. List Prestashop products to online
            marketplaces, manage all orders in one place, take control of every aspect of your inventory management and
            all listing-related updates between Prestashop and online marketplaces.
';
    }

    public function install()
    {
        return parent::install()
            && $this->registerHook('displayBackOfficeHeader')
            && $this->registerHook('addWebserviceResources')
            && $this->registerHook('actionUpdateQuantity')
            && $this->installTab()
            && $this->loginInSC();
    }

    public function uninstall()
    {
        $this->uninstallTab();
        $this->deleteWebserviceKey($this->name);
        $this->unregisterHook('displayBackOfficeHeader');
        $this->unregisterHook('addWebserviceResources');
        $this->unregisterHook('actionUpdateQuantity');

        return parent::uninstall();
    }

    public function enable($force_all = false)
    {
        return parent::enable($force_all)
            && $this->registerHook('displayBackOfficeHeader')
            && $this->registerHook('addWebserviceResources')
            && $this->registerHook('actionUpdateQuantity')
            && $this->installTab()
            && $this->loginInSC();
    }

    public function disable($force_all = false)
    {
        $this->uninstallTab();
        $this->deleteWebserviceKey($this->name);
        $this->unregisterHook('displayBackOfficeHeader');
        $this->unregisterHook('addWebserviceResources');
        $this->unregisterHook('actionUpdateQuantity');

        return parent::disable($force_all);
    }

    public function hookAddWebserviceResources($params)
    {
        if (!interface_exists('WebserviceSpecificManagementInterface')) {
            @require_once _PS_ROOT_DIR_ . '/classes/webservice/WebserviceSpecificManagementInterface.php';
        }

        require_once __DIR__ . '/classes/WebserviceSpecificManagementM2e.php';

        return [
            'm2e' => [
                'description' => 'M2E',
                'class' => 'WebserviceSpecificManagementM2e',
                'specific_management' => true,
            ],
        ];
    }

    public function hookDisplayBackOfficeHeader()
    {
        $this->context->controller->addCSS($this->_path . 'views/css/admin.css');
    }

    private function getTabId($className)
    {
        return SymfonyContainer::getInstance()
            ->get('prestashop.core.admin.tab.repository')
            ->findOneIdByClassName($className);
    }

    private function installTab()
    {
        if ($this->getTabId(self::ADMIN_TAB_CLASS_NAME)) {
            return true;
        }

        $mainTab = new Tab();
        $mainTab->active = true;
        $mainTab->class_name = self::ADMIN_TAB_CLASS_NAME;
        $mainTab->name = [];

        foreach (Language::getLanguages(true) as $lang) {
            $mainTab->name[$lang['id_lang']] = $this->displayName;
        }

        $mainTab->id_parent = $this->getTabId('SELL');
        $mainTab->module = $this->name;
        $mainTab->icon = version_compare(_PS_VERSION_, '1.7.6.0', '>=') ? 'rocket_launch' : 'extension';

        $mainTab->add();

        return true;
    }

    private function uninstallTab()
    {
        if ($idTab = $this->getTabId(self::ADMIN_TAB_CLASS_NAME)) {
            $tab = new Tab($idTab);
            $tab->delete();
        }
    }

    public static function getWebserviceKey($description)
    {
        $sql = sprintf(
            'SELECT * FROM %swebservice_account WHERE description = "%s"',
            _DB_PREFIX_,
            pSQL($description)
        );

        $result = Db::getInstance()->getRow($sql);

        return $result ? $result['key'] : null;
    }

    public static function getWebserviceKeyId($wsKey)
    {
        $sql = sprintf(
            'SELECT id_webservice_account FROM `%swebservice_account` WHERE `key` = "%s"',
            _DB_PREFIX_,
            pSQL($wsKey)
        );

        return (int) Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue($sql);
    }

    public function createWebserviceKey($description)
    {
        if (!Configuration::get('PS_WEBSERVICE')) {
            Configuration::updateValue('PS_WEBSERVICE', 1);
        }

        if ($key = $this->getWebserviceKey($description)) {
            return $key;
        }

        $key = bin2hex(Tools::passwdGen(16));

        $wsKey = new WebserviceKey();
        $wsKey->key = $key;
        $wsKey->description = $description;
        $wsKey->active = true;

        if (!$wsKey->add()) {
            throw new Exception('Failed to create Webservice Key.');
        }

        $this->setWebserviceKeyPermissions($wsKey->id);

        return $key;
    }

    public function setWebserviceKeyPermissions($keyId)
    {
        $resources = [
            'm2e' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'addresses' => ['GET' => 1],
            'carriers' => ['GET' => 1],
            'carts' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'categories' => ['GET' => 1],
            'combinations' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'configurations' => ['GET' => 1],
            'countries' => ['GET' => 1],
            'currencies' => ['GET' => 1],
            'customers' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'deliveries' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'images' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'languages' => ['GET' => 1],
            'manufacturers' => ['GET' => 1],
            'order_carriers' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'order_details' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'order_payments' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'order_states' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'orders' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'product_option_values' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'product_options' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'products' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'shops' => ['GET' => 1],
            'stock_availables' => ['GET' => 1, 'PUT' => 1, 'POST' => 1, 'PATCH' => 1],
            'taxes' => ['GET' => 1],
        ];
        foreach ($resources as $resource => $methods) {
            foreach ($methods as $method => $value) {
                Db::getInstance()->insert(
                    'webservice_permission',
                    [
                        'id_webservice_account' => $keyId,
                        'resource' => pSQL($resource),
                        'method' => pSQL(strtoupper($method)),
                    ],
                    false,
                    true,
                    Db::ON_DUPLICATE_KEY
                );
            }
        }
    }

    public function deleteWebserviceKey($description)
    {
        $results = Db::getInstance()->executeS(
            'SELECT id_webservice_account FROM ' . _DB_PREFIX_ . 'webservice_account WHERE description = "' . pSQL($description) . '"'
        );

        foreach ($results as $row) {
            $webserviceKey = new WebserviceKey((int) $row['id_webservice_account']);
            $webserviceKey->delete();
        }
    }

    public function getShopCurrencyIsoCode()
    {
        $idCurrency = (int) Configuration::get('PS_CURRENCY_DEFAULT');
        $currency = new Currency($idCurrency);

        return $currency->iso_code;
    }

    public function getShopCountryIsoCode()
    {
        $idCountry = (int) Configuration::get('PS_COUNTRY_DEFAULT');
        $country = new Country($idCountry);

        return $country->iso_code;
    }

    public function loginInSC()
    {
        $employee = $this->context->employee;

        $this->callSC(
            'prestashop/account/login/',
            [
                'url' => rtrim(Tools::getShopDomainSsl(true)) . __PS_BASE_URI__,
                'api_key' => $this->createWebserviceKey($this->name),
                'app_name' => 'bundle',
                'app_version' => $this->version,
                'app_source' => 'github',
                'email' => $employee->email,
                'name' => implode(' ', [$employee->firstname, $employee->lastname]),
                'domain' => Tools::getShopDomain(),
                'admin_url' => strtok($this->context->link->getAdminLink('AdminDashboard'), '?'),
                'shop_name' => Configuration::get('PS_SHOP_NAME'),
                'timezone' => Configuration::get('PS_TIMEZONE'),
                'currency' => $this->getShopCurrencyIsoCode(),
                'country_code' => $this->getShopCountryIsoCode(),
            ]
        );

        return true;
    }

    private function callSC($path, $data)
    {
        $payload = json_encode($data);

        $c = curl_init('https://m2e.cloud/api/v1/' . $path);
        curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($c, CURLOPT_POST, true);
        curl_setopt($c, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($c, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($payload),
        ]);

        $response = curl_exec($c);
        $httpCode = curl_getinfo($c, CURLINFO_HTTP_CODE);

        if (curl_errno($c)) {
            $error = curl_error($c);
            PrestaShopLogger::addLog('External API error: ' . $error, 3);
        }

        curl_close($c);

        return [
            'status' => $httpCode,
            'response' => $response,
        ];
    }

    private function sendWebhook($event, $data)
    {
        $url = 'https://m2e.cloud/webhook/prestashop/webhook/bundle/';
        $apiKey = self::getWebserviceKey($this->name);

        if (!$apiKey) {
            return [];
        }

        $payload = json_encode([
            'domain' => Tools::getShopDomain(),
            'event' => $event,
            'data' => $data,
            'timestamp' => date('Y-m-d H:i:s', time()),
        ]);

        $signature = hash_hmac('sha256', $payload, $apiKey);

        $c = curl_init($url);
        curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($c, CURLOPT_POST, true);
        curl_setopt($c, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($c, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'X-Webhook-Signature: ' . $signature,
        ]);

        $response = curl_exec($c);
        $httpCode = curl_getinfo($c, CURLINFO_HTTP_CODE);

        curl_close($c);

        return [
            'status' => $httpCode,
            'response' => $response,
        ];
    }

    public function hookActionUpdateQuantity($params)
    {
        $this->sendWebhook(
            'product.quantity_updated',
            [
                'id_product' => (string) $params['id_product'],
                'id_product_attribute' => $params['id_product_attribute'] ? (string) $params['id_product_attribute'] : null,
                'quantity' => (int) $params['quantity'],
            ]
        );
    }
}
