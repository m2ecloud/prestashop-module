<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2026 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * @param M2eMultichannelConnect $object
 */
function upgrade_module_1_2_12($object)
{
    $wsKey = $object->createWebserviceKey($object->name);
    $object->setWebserviceKeyPermissions($object::getWebserviceKeyId($wsKey));
    $object->loginInSC();

    return true;
}
