<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Adapter\SymfonyContainer;

/**
 * @param M2eMultichannelConnect $object
 */
function upgrade_module_1_2_6($object)
{
    $tabRepository = SymfonyContainer::getInstance()->get('prestashop.core.admin.tab.repository');

    $tabId = $tabRepository->findOneIdByClassName(M2eMultichannelConnect::ADMIN_TAB_CLASS_NAME);
    if (!$tabId) {
        return true;
    }

    $tab = new Tab($tabId);
    $tab->icon = version_compare(_PS_VERSION_, '1.7.6.0', '>=') ? 'rocket_launch' : 'extension';
    $tab->save();

    return true;
}
