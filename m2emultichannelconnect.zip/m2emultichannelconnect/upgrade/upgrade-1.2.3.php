<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Adapter\SymfonyContainer;

/**
 * @param M2eMultichannelConnect $object
 */
function upgrade_module_1_2_3($object)
{
    $tabRepository = SymfonyContainer::getInstance()->get('prestashop.core.admin.tab.repository');

    $tabId = $tabRepository->findOneIdByClassName(M2eMultichannelConnect::ADMIN_TAB_CLASS_NAME);
    if (!$tabId) {
        return true;
    }

    $newParentTabId = $tabRepository->findOneIdByClassName('SELL');
    if (!$newParentTabId) {
        return true;
    }

    $tab = new Tab($tabId);
    $tab->id_parent = $newParentTabId;
    $tab->save();

    return true;
}
