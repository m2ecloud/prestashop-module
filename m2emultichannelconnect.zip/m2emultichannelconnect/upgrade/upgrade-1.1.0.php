<?php
/**
 * @author     M2E LTD Developers Team
 * @copyright  2011-2025 M2E LTD
 * @license    Any usage is forbidden
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * @param M2eMultichannelConnect $object
 */
function upgrade_module_1_1_0($object)
{
    if (!$object->isRegisteredInHook('addWebserviceResources')) {
        $object->registerHook('addWebserviceResources');
    }

    if (!$object->isRegisteredInHook('actionUpdateQuantity')) {
        $object->registerHook('actionUpdateQuantity');
    }

    $wsKey = $object->createWebserviceKey($object->name);
    $object->setWebserviceKeyPermissions($object::getWebserviceKeyId($wsKey));
    $object->loginInSC();

    return true;
}
